"use client"

import { MapPin, PieChart, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function Sidebar() {
  return (
    <aside className="w-64 bg-sidebar border-r border-sidebar-border">
      <div className="p-6 space-y-8">
        {/* Navigation Links */}
        <nav className="space-y-2">
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <MapPin className="w-5 h-5" />
            <span>My Bookings</span>
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <PieChart className="w-5 h-5" />
            <span>Analytics</span>
          </Button>
          <Button
            variant="ghost"
            className="w-full justify-start gap-3 text-sidebar-foreground hover:bg-sidebar-accent"
          >
            <Settings className="w-5 h-5" />
            <span>Settings</span>
          </Button>
        </nav>
      </div>
    </aside>
  )
}
