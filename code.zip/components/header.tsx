"use client"

import { Bell, Search, User } from "lucide-react"
import { Button } from "@/components/ui/button"

interface HeaderProps {
  onNotificationClick: () => void
}

export default function Header({ onNotificationClick }: HeaderProps) {
  return (
    <header className="border-b border-border bg-card shadow-sm">
      <div className="px-6 py-4 flex items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
            <span className="text-primary-foreground font-bold text-lg">P</span>
          </div>
          <span className="font-bold text-lg hidden sm:inline">ParkFinder</span>
        </div>

        {/* Navigation Tabs */}
        <nav className="hidden md:flex items-center gap-1">
          <Button variant="ghost" size="sm" className="text-foreground hover:bg-muted">
            Home
          </Button>
          <Button variant="ghost" size="sm" className="text-foreground hover:bg-muted">
            Map
          </Button>
          <Button variant="ghost" size="sm" className="text-foreground hover:bg-muted">
            Help
          </Button>
        </nav>

        {/* Search Bar */}
        <div className="flex-1 max-w-md mx-4 hidden md:flex">
          <div className="relative w-full">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <input
              type="text"
              placeholder="Search locations..."
              className="w-full pl-10 pr-4 py-2 rounded-lg bg-muted border border-border text-sm focus:outline-none focus:ring-2 focus:ring-primary"
            />
          </div>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-3 shrink-0">
          <Button
            variant="ghost"
            size="icon"
            className="text-foreground hover:bg-muted relative"
            onClick={onNotificationClick}
          >
            <Bell className="w-5 h-5" />
            <span className="absolute top-0 right-0 w-2 h-2 bg-error rounded-full"></span>
          </Button>
          <Button variant="ghost" size="icon" className="text-foreground hover:bg-muted">
            <User className="w-5 h-5" />
          </Button>
        </div>
      </div>
    </header>
  )
}
