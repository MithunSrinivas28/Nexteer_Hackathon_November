"use client"

import { useState } from "react"
import { X, DollarSign, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface ParkingSpot {
  id: number
  name: string
  available: boolean
  distance?: number
}

interface BookingModalProps {
  spot: ParkingSpot
  onClose: () => void
}

export default function BookingModal({ spot, onClose }: BookingModalProps) {
  const [duration, setDuration] = useState(2)
  const hourlyRate = 5.5
  const totalCost = (duration * hourlyRate).toFixed(2)

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <Card className="bg-card border border-border w-full max-w-md p-0 shadow-xl">
        {/* Header */}
        <div className="px-6 py-4 border-b border-border flex items-center justify-between">
          <h3 className="font-semibold text-lg text-foreground">Book Parking Spot</h3>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-6">
          {/* Spot Details */}
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5 text-success" />
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">{spot.name}</p>
                <p className="text-xs text-muted-foreground mt-1">{spot.distance} km away</p>
              </div>
            </div>
          </div>

          {/* Duration Selection */}
          <div>
            <label className="block text-sm font-medium text-foreground mb-3">Duration (Hours)</label>
            <div className="space-y-3">
              <input
                type="range"
                min="1"
                max="24"
                value={duration}
                onChange={(e) => setDuration(Number.parseInt(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-primary"
              />
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">1 hour</span>
                <span className="font-medium text-foreground">{duration} hours</span>
                <span className="text-muted-foreground">24 hours</span>
              </div>
            </div>
          </div>

          {/* Pricing Breakdown */}
          <div className="bg-muted rounded-lg p-4 space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Hourly Rate</span>
              <span className="font-medium text-foreground">${hourlyRate.toFixed(2)}</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-muted-foreground">Duration</span>
              <span className="font-medium text-foreground">{duration}h</span>
            </div>
            <div className="border-t border-border pt-2 flex items-center justify-between">
              <span className="font-medium text-foreground">Total Cost</span>
              <div className="flex items-center gap-1">
                <DollarSign className="w-4 h-4 text-success" />
                <span className="text-lg font-bold text-success">{totalCost}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-border flex gap-3">
          <Button variant="outline" className="flex-1 border-border bg-transparent" onClick={onClose}>
            Cancel
          </Button>
          <Button className="flex-1 bg-primary text-primary-foreground hover:bg-primary/90">Confirm Booking</Button>
        </div>
      </Card>
    </div>
  )
}
