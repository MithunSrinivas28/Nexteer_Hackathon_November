"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { MapPin, AlertCircle, TrendingUp, Layers } from "lucide-react"

interface InfoCardsProps {
  onHeatMapToggle: (enabled: boolean) => void
  heatMapEnabled: boolean
}

export default function InfoCards({ onHeatMapToggle, heatMapEnabled }: InfoCardsProps) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {/* Available Spots */}
      <Card className="bg-card border border-border p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Available Spots</p>
            <p className="text-3xl font-bold text-success mt-2">234</p>
          </div>
          <div className="w-10 h-10 bg-success/10 rounded-lg flex items-center justify-center">
            <MapPin className="w-5 h-5 text-success" />
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-3">+12 from last hour</p>
      </Card>

      {/* Occupied Spots */}
      <Card className="bg-card border border-border p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Occupied Spots</p>
            <p className="text-3xl font-bold text-error mt-2">156</p>
          </div>
          <div className="w-10 h-10 bg-error/10 rounded-lg flex items-center justify-center">
            <AlertCircle className="w-5 h-5 text-error" />
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-3">-5 from last hour</p>
      </Card>

      {/* Total Spots */}
      <Card className="bg-card border border-border p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Total Spots</p>
            <p className="text-3xl font-bold text-primary mt-2">390</p>
          </div>
          <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center">
            <TrendingUp className="w-5 h-5 text-primary" />
          </div>
        </div>
        <p className="text-xs text-muted-foreground mt-3">100% coverage</p>
      </Card>

      {/* Heat Map Toggle */}
      <Card className="bg-card border border-border p-4">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs text-muted-foreground font-medium">Traffic Overlay</p>
            <Button
              size="sm"
              onClick={() => onHeatMapToggle(!heatMapEnabled)}
              className={`mt-3 ${
                heatMapEnabled ? "bg-primary text-primary-foreground" : "bg-muted text-foreground hover:bg-muted/80"
              }`}
            >
              {heatMapEnabled ? "Enabled" : "Disabled"}
            </Button>
          </div>
          <div className="w-10 h-10 bg-warning/10 rounded-lg flex items-center justify-center">
            <Layers className="w-5 h-5 text-warning" />
          </div>
        </div>
      </Card>
    </div>
  )
}
