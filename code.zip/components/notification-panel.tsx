"use client"

import { X, AlertCircle, CheckCircle, Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"

interface NotificationPanelProps {
  onClose: () => void
}

export default function NotificationPanel({ onClose }: NotificationPanelProps) {
  const notifications = [
    {
      id: 1,
      type: "success",
      title: "Booking Confirmed",
      message: "Your parking spot at Lot A has been booked for 2 hours",
      time: "5 min ago",
    },
    {
      id: 2,
      type: "warning",
      title: "High Traffic Alert",
      message: "Heavy congestion detected near downtown parking areas",
      time: "15 min ago",
    },
    {
      id: 3,
      type: "info",
      title: "Parking Rate Update",
      message: "Off-peak rates are now active. Save up to 30% until 6 PM",
      time: "1 hour ago",
    },
  ]

  const getIcon = (type: string) => {
    switch (type) {
      case "success":
        return <CheckCircle className="w-5 h-5 text-success" />
      case "warning":
        return <AlertCircle className="w-5 h-5 text-warning" />
      case "info":
        return <Info className="w-5 h-5 text-primary" />
      default:
        return <Info className="w-5 h-5" />
    }
  }

  return (
    <div className="w-80 bg-card border-l border-border shadow-lg flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-border flex items-center justify-between">
        <h2 className="font-semibold text-foreground">Notifications</h2>
        <Button variant="ghost" size="icon" onClick={onClose}>
          <X className="w-4 h-4" />
        </Button>
      </div>

      {/* Notifications List */}
      <div className="flex-1 overflow-auto space-y-2 p-4">
        {notifications.map((notif) => (
          <Card key={notif.id} className="p-3 bg-card border border-border hover:border-primary/30 transition-colors">
            <div className="flex gap-3">
              <div className="flex-shrink-0 mt-1">{getIcon(notif.type)}</div>
              <div className="flex-1 min-w-0">
                <p className="font-medium text-sm text-foreground">{notif.title}</p>
                <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{notif.message}</p>
                <p className="text-xs text-muted-foreground/60 mt-2">{notif.time}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Footer */}
      <div className="p-4 border-t border-border">
        <Button className="w-full bg-muted text-foreground hover:bg-muted/80" size="sm">
          View All
        </Button>
      </div>
    </div>
  )
}
