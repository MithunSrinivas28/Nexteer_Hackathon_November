"use client"

import { Button } from "@/components/ui/button"
import { Bike, Car, Zap } from "lucide-react"

interface VehicleCategoryProps {
  selectedCategory: string
  onCategoryChange: (category: string) => void
}

export default function VehicleCategory({ selectedCategory, onCategoryChange }: VehicleCategoryProps) {
  const categories = [
    { id: "2w", label: "2-Wheeler", icon: Bike },
    { id: "4w", label: "4-Wheeler", icon: Car },
    { id: "ev", label: "EV", icon: Zap },
  ]

  return (
    <div className="bg-card rounded-lg p-4 border border-border">
      <h3 className="text-sm font-semibold text-foreground mb-3">Vehicle Category</h3>
      <div className="flex gap-3">
        {categories.map((cat) => {
          const Icon = cat.icon
          return (
            <Button
              key={cat.id}
              onClick={() => onCategoryChange(cat.id)}
              className={`flex-1 flex items-center justify-center gap-2 ${
                selectedCategory === cat.id
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-foreground hover:bg-muted/80"
              }`}
              size="sm"
            >
              <Icon className="w-4 h-4" />
              <span className="hidden sm:inline">{cat.label}</span>
            </Button>
          )
        })}
      </div>
    </div>
  )
}
