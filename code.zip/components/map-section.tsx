"use client"

import { useState, useEffect } from "react"
import { MapPin, Maximize2 } from "lucide-react"
import { Button } from "@/components/ui/button"

interface ParkingSpot {
  id: number
  name: string
  lat: number
  lng: number
  available: boolean
  category: string
  distance?: number
}

interface MapSectionProps {
  heatMapEnabled: boolean
  onBookSpot: (spot: ParkingSpot) => void
  selectedCategory: string
}

export default function MapSection({ heatMapEnabled, onBookSpot, selectedCategory }: MapSectionProps) {
  const [spots, setSpots] = useState<ParkingSpot[]>([])
  const [userLocation, setUserLocation] = useState({ lat: 40.7128, lng: -74.006 })
  const [hoveredSpot, setHoveredSpot] = useState<number | null>(null)

  useEffect(() => {
    // Mock parking spots data
    const mockSpots: ParkingSpot[] = [
      { id: 1, name: "Lot A - Premium", lat: 40.7135, lng: -74.0022, available: true, category: "4w", distance: 0.2 },
      { id: 2, name: "Lot B - Street", lat: 40.7089, lng: -74.0086, available: false, category: "2w", distance: 0.5 },
      {
        id: 3,
        name: "Lot C - EV Station",
        lat: 40.7209,
        lng: -73.9999,
        available: true,
        category: "ev",
        distance: 0.8,
      },
      { id: 4, name: "Lot D - Garage", lat: 40.716, lng: -74.0041, available: true, category: "4w", distance: 0.3 },
      { id: 5, name: "Lot E - Underground", lat: 40.71, lng: -74.005, available: false, category: "4w", distance: 0.6 },
    ]
    setSpots(mockSpots)

    const interval = setInterval(() => {
      setSpots((prev) =>
        prev.map((spot) => {
          if (Math.random() > 0.7) {
            return { ...spot, available: !spot.available }
          }
          return spot
        }),
      )
    }, 5000)

    return () => clearInterval(interval)
  }, [])

  const filteredSpots = spots.filter((spot) => spot.category === selectedCategory)

  return (
    <div className="relative w-full h-full bg-gradient-to-br from-muted to-background flex items-center justify-center overflow-hidden">
      {/* Map Container */}
      <div className="w-full h-full relative bg-muted/50 border border-border">
        {/* Mock Map Background */}
        <div className="absolute inset-0 bg-gradient-to-br from-blue-50 to-slate-100 dark:from-slate-800 dark:to-slate-900">
          {/* Grid Pattern */}
          <div
            className="absolute inset-0 opacity-5"
            style={{
              backgroundImage:
                "linear-gradient(0deg, #000 1px, transparent 1px), linear-gradient(90deg, #000 1px, transparent 1px)",
              backgroundSize: "50px 50px",
            }}
          ></div>
        </div>

        {/* Parking Spots */}
        <div className="absolute inset-0 p-8 flex items-center justify-center">
          <div className="relative w-full h-full">
            {/* User Location Marker */}
            <div className="absolute top-1/3 left-1/3 transform -translate-x-1/2 -translate-y-1/2 z-10">
              <div className="w-6 h-6 bg-primary rounded-full border-3 border-primary-foreground shadow-lg flex items-center justify-center">
                <div className="w-2 h-2 bg-primary-foreground rounded-full"></div>
              </div>
              <div className="absolute inset-0 w-6 h-6 bg-primary rounded-full animate-pulse opacity-30"></div>
            </div>

            {/* Parking Spot Markers */}
            {filteredSpots.map((spot, index) => {
              const angle = (index * 360) / Math.max(filteredSpots.length, 1)
              const radius = 150
              const x = Math.cos((angle * Math.PI) / 180) * radius
              const y = Math.sin((angle * Math.PI) / 180) * radius

              return (
                <div
                  key={spot.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-all"
                  style={{
                    left: `calc(50% + ${x}px)`,
                    top: `calc(50% + ${y}px)`,
                    zIndex: hoveredSpot === spot.id ? 20 : 10,
                  }}
                  onMouseEnter={() => setHoveredSpot(spot.id)}
                  onMouseLeave={() => setHoveredSpot(null)}
                >
                  {/* Marker */}
                  <div
                    className={`w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-xs transition-all transform ${
                      spot.available ? "bg-success hover:scale-125 shadow-lg" : "bg-error hover:scale-125 shadow-lg"
                    } ${hoveredSpot === spot.id ? "scale-125" : "scale-100"}`}
                  >
                    {spot.available ? "✓" : "✕"}
                  </div>

                  {/* Tooltip */}
                  {hoveredSpot === spot.id && (
                    <div className="absolute left-12 top-0 bg-card border border-border rounded-lg shadow-xl p-3 w-56 z-30 animate-in fade-in duration-200">
                      <div className="flex items-start gap-2 mb-2">
                        <MapPin className="w-4 h-4 text-primary flex-shrink-0 mt-0.5" />
                        <div>
                          <h4 className="font-semibold text-sm text-foreground">{spot.name}</h4>
                          <p className="text-xs text-muted-foreground mt-1">{spot.distance} km away</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-2 mb-3">
                        <div
                          className={`px-2 py-1 rounded text-xs font-medium ${
                            spot.available ? "bg-success/10 text-success" : "bg-error/10 text-error"
                          }`}
                        >
                          {spot.available ? "Available" : "Occupied"}
                        </div>
                      </div>
                      <Button
                        size="sm"
                        className="w-full bg-primary text-primary-foreground hover:bg-primary/90"
                        onClick={() => onBookSpot(spot)}
                        disabled={!spot.available}
                      >
                        Book Now
                      </Button>
                    </div>
                  )}
                </div>
              )
            })}

            {/* Heat Map Overlay */}
            {heatMapEnabled && (
              <div className="absolute inset-0 bg-gradient-to-br from-warning/20 via-error/10 to-transparent rounded-lg animate-pulse"></div>
            )}
          </div>
        </div>

        {/* Expand Button */}
        <Button
          size="icon"
          className="absolute bottom-6 right-6 bg-primary text-primary-foreground hover:bg-primary/90 shadow-lg z-20"
        >
          <Maximize2 className="w-5 h-5" />
        </Button>
      </div>
    </div>
  )
}
