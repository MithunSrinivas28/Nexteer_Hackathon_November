"use client"

import { useState } from "react"
import Header from "@/components/header"
import MapSection from "@/components/map-section"
import InfoCards from "@/components/info-cards"
import VehicleCategory from "@/components/vehicle-category"
import NotificationPanel from "@/components/notification-panel"
import BookingModal from "@/components/booking-modal"

export default function Home() {
  const [selectedCategory, setSelectedCategory] = useState("4w")
  const [showNotifications, setShowNotifications] = useState(false)
  const [showBooking, setShowBooking] = useState(false)
  const [selectedSpot, setSelectedSpot] = useState(null)
  const [heatMapEnabled, setHeatMapEnabled] = useState(false)

  const handleBookSpot = (spot) => {
    setSelectedSpot(spot)
    setShowBooking(true)
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header onNotificationClick={() => setShowNotifications(!showNotifications)} />

      <div className="flex flex-1 overflow-hidden">
        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Info Cards and Category Section */}
          <div className="p-6 border-b border-border overflow-auto">
            <div className="space-y-4">
              <VehicleCategory selectedCategory={selectedCategory} onCategoryChange={setSelectedCategory} />
              <InfoCards onHeatMapToggle={setHeatMapEnabled} heatMapEnabled={heatMapEnabled} />
            </div>
          </div>

          {/* Map Section */}
          <div className="flex-1 overflow-hidden">
            <MapSection
              heatMapEnabled={heatMapEnabled}
              onBookSpot={handleBookSpot}
              selectedCategory={selectedCategory}
            />
          </div>
        </div>

        {/* Notification Panel */}
        {showNotifications && <NotificationPanel onClose={() => setShowNotifications(false)} />}
      </div>

      {/* Booking Modal */}
      {showBooking && selectedSpot && <BookingModal spot={selectedSpot} onClose={() => setShowBooking(false)} />}
    </div>
  )
}
